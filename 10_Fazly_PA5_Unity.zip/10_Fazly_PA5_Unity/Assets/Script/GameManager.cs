﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager instance = null;
    public Text scoretxt;
    public int score;
    
    public void Awake()
    {
        //Check if instance already exists
        if (instance == null)
        {
            //if not, set instance to this
            instance = this;
        }
        else if (instance != this)
        {
            //Then destroy this. This enforces our singleton pattern,
            //meaning there can only be one instance of a GameManager.
            Destroy(gameObject);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void AddScore(int count)
    {
        score += count;
        
        print(score);
    }

    public void GoToLose()
    {
        SceneManager.LoadScene("GameLose");
    }

    public void GoToWin()
    {
        SceneManager.LoadScene("GameWin");
    }

    public void GoToLevel2()
    {
        SceneManager.LoadScene("LEVEL2");
    }
}
